# IOT
I have posted my work on IOT Projects

Here you can find the basic and advanced sensor which i have worked on solving minor and major day to day issues.

If you are looking to learn about IOT you can take my work as reference.

For contact you can mail to budigeavinash382@gmail.com
